# LEGO Builders Club

A mockup concept website promoting inclusion and creativity among all LEGO builders.  
Built using Tailwind CSS and hosted on GitHub Pages.

**Big Idea:** If you build, you belong.  
**Tagline:** One club. Every kind of builder.
